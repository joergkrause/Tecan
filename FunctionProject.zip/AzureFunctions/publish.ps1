$resourceGroupName = "rg-tecan-dev"
$functionAppName = "func-tecanworkshop-dev"
$webJobsStorage = "DefaultEndpointsProtocol=https;AccountName=sttecanwsdev;AccountKey=ihQ3xaD9lhdHIXTFnFfT104UmvD03XJdoGaoe8fmEW8AGJtDlbdGO9WU83pOeUb8qPdJGPnA3zIk+ASthzFrFw==;EndpointSuffix=core.windows.net"

$publishPath = "./publish"
dotnet publish -c Release -o $publishPath

$publishZip = "./publish.zip"
if (Test-Path $publishZip) {
  Remove-Item $publishZip
}
Compress-Archive -Path "$publishPath\*" -DestinationPath $publishZip

az functionapp deployment source config-zip -g $resourceGroupName -n $functionAppName --src $publishZip

az functionapp config appsettings set -g $resourceGroupName -n $functionAppName --settings `
  "AzureWebJobsStorage=$webJobsStorage" `
  "DataIngressQueue=data-ingress"
