namespace Tecan.Function;

public class IotData
{

  public int Value { get; set; }

  public string DeviceId { get; set; }

  public string DeviceType { get; set; }

}
